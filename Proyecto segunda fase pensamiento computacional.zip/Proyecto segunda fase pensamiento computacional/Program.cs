﻿using System;

class Program
{
    static void Main(string[]args)
    {     
       


            Console.WriteLine("Una empresa en colaboración con la universidad Rafael Landivar");
            Console.WriteLine("-              --------------             -");
            Console.WriteLine("--                 -----                 --");
            Console.WriteLine("--- ♡♡Máquina generadora de licuados♡♡ ---");
            Console.WriteLine("--                 -----                 --");
            Console.WriteLine("-              --------------             -");
            Console.WriteLine(" ");
            Console.WriteLine(" ");
            Console.WriteLine("Bienvenidos a la máquina de licuados");
            Console.WriteLine(" ");
            Console.WriteLine(" ");
            Console.WriteLine("<<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>>"); 
            Console.WriteLine("<                                              >");
            Console.WriteLine("♡¿Cómo desea personalizar su licuado de fresa?♡");
            Console.WriteLine("<                                              >");
            Console.WriteLine("<<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>>"); 
            Console.WriteLine(" ");
            Console.WriteLine("<<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>><<>>"); 
            Console.WriteLine(" ");
            Console.WriteLine("Para empezar por favor ingresar su nombre completo: ");
            string nombre = Console.ReadLine();
            

        Console.WriteLine("¿Desea ingresar su NIT?");
        Console.WriteLine(" ");
        Console.WriteLine(" Para aceptar escriba si");
        Console.WriteLine(" Para rechazar escriba no");
        string NITc = Console.ReadLine();
        string NITCliente = "";
        if (NITc == "si")
        {
            Console.WriteLine("Por favor ingresar su NIT: ");
            NITCliente = Console.ReadLine();
        }
        //Aclaro que aquí se empiezan a declarar variables todas juntas en lugar de ordenadas por cada uso porque algunas se usarán fuera y adentro de switch
        string TipoAzucar = "sin azúcar";
        double precioAzucar = 0.0;
        int cantidadAzucar = 0;
        string tipoLeche = "leche deslactosada";
        double precioLeche = 0.0;
        double precioDescuentoLeche = 2.0;
        double precioAumentoLeche = 3.0;
        double precioLicuado = 5.0; 
        double precioAgrandado = 0.0; 
        bool agrandado = false; 
        bool aceptar = false;
        bool salir = false;
        while (!salir)
        {

            double preciototal = precioLicuado + precioAzucar * cantidadAzucar + precioLeche;
                    if (agrandado)
                    {
                        preciototal += preciototal * 0.07; 
                    }
            Console.WriteLine(" ");
            Console.WriteLine(" ");
            Console.WriteLine("------------------------------");
            Console.WriteLine("-------------MENÚ-------------");
            Console.WriteLine("1. Ver información de mi pedido");
            Console.WriteLine("2. Agregar azúcar");
            Console.WriteLine("3. Modificar la leche");
            Console.WriteLine("4. Agrandar mi pedido");
            Console.WriteLine("5. Confirmar el pedido");
            Console.WriteLine("6. Información de la máquina");
            Console.WriteLine("7. Salir de la máquina");
            Console.Write("Por favor seleccionar una opcion:  ");
            string opcion = Console.ReadLine();
            Console.WriteLine("------------------------------");
            switch (opcion)
            {
                case "1":
                    Console.WriteLine("Información del pedido");
                    Console.WriteLine($"Nombre del cliente: {nombre}");
                    Console.WriteLine($"NIT del cliente: {NITCliente}");
                    DateTime hoy = DateTime.Now;
                    Console.WriteLine($"la fecha es: {hoy}");
                    Console.WriteLine($"Tipo de licuado ordenado: Fresa con {tipoLeche} y {TipoAzucar}");
                    Console.WriteLine($"Cantidad de azúcar: {cantidadAzucar} cucharaditas");
                    Console.WriteLine($"Precio del licuado: Q.{preciototal}");
                    Console.Write(" ¿Continuar? "); //apartado hecho solo para que la sección de información sea visible y no se vaya para atrás
                    Console.ReadLine();
                    break;


                case "2":
                 
                    if (cantidadAzucar < 3)
                    {
                        Console.WriteLine("¿Qué tipo de azúcar desea escoger?");
                        Console.WriteLine(" ");
                        Console.WriteLine("1. Azúcar blanca ♡(Q.0.50 por cucharadita)");
                        Console.WriteLine("2. Azúcar morena ♡(Q.0.40 por cucharadita)");
                        Console.WriteLine("3. Suplemento de azúcar ♡(Q.0.60 por cucharadita)");
                        Console.WriteLine(" ");
                        Console.Write("Por favor seleccionar el tipo de azúcar: ");
                        string ta = Console.ReadLine();

                        switch (ta)
                        {
                            case "1":
                                TipoAzucar = "azúcar blanca";
                                precioAzucar = 0.50;
                                break;
                            case "2":
                                TipoAzucar = "azúcar morena";
                                precioAzucar = 0.40;
                                break;
                            case "3":
                                TipoAzucar = "suplemento de azúcar";
                                precioAzucar = 0.60;
                                break;
                            default:
                                Console.WriteLine("La opción que seleccionó no es válida");
                                continue;
                        }

                        cantidadAzucar++;
                        Console.WriteLine($"Se agregó {TipoAzucar} a su orden, total de azúcar agregada: {cantidadAzucar} cucharaditas");
                    }
                    else
                    {
                        Console.WriteLine("Su orden alcanzó el límite de cucharaditas de azúcar");
                    }
                    break;

                case "3":
                   
                    Console.WriteLine("Tipos de leche:");
                    Console.WriteLine("1. Sin leche (únicamente con agua)");
                    Console.WriteLine("2. Leche deslactosada");
                    Console.WriteLine("3. Leche entera");
                    Console.WriteLine("4. Leche de soya");
                    Console.Write("Por favor seleccione el tipo de leche que desea:  ");
                    string TipoLecheSss = Console.ReadLine();

                    switch (TipoLecheSss)
                    {
                        case "1":
                            tipoLeche = "sin leche";
                            precioLeche = -precioDescuentoLeche; 
                            break;
                        case "2":
                            tipoLeche = "leche deslactosada";
                            precioLeche = 0.0;
                            break;
                        case "3":
                            tipoLeche = "leche entera";
                            precioLeche = 0.0;
                            break;
                        case "4":
                            tipoLeche = "leche de soya";
                            precioLeche = precioAumentoLeche; 
                            break;
                        default:
                            Console.WriteLine("La opción no es válida ");
                            break;
                    }
                    Console.WriteLine($"Se seleccionó {tipoLeche} para su orden");
                    break;

                case "4":
                    Console.WriteLine("¿Desea agregar un agrandado a su licuado por un recargo adicional del 7%?");
                    Console.WriteLine(" Para aceptar: si");
                    Console.WriteLine(" Para denegar: no");
                    string sn = Console.ReadLine();
                    {
                    if (sn == "si")
                    {
                        agrandado = true;
                    Console.WriteLine("Se ha agregado el agrandado a su orden, ahora su licuado es de tamaño grande");
                    }
                    else
                    {
                        agrandado = false;
                    Console.WriteLine("El agrandado no ha sido agregado a su orden, su licuado es de tamaño mediano");
                    }
                    }
                    break;

                    case "5":
                    
                    Console.WriteLine("---------- Confirmando su pedido... ----------");
                    Console.WriteLine("¿Es correcta la información de su pedido?");
                    Console.WriteLine(" ");
                    Console.WriteLine(">>>>>>>>>>Información del pedido<<<<<<<<<<");
                    Console.WriteLine($"Nombre del cliente: {nombre}");
                    Console.WriteLine($"NIT del cliente: {NITCliente}");
                    DateTime hoyb = DateTime.Now;
                    Console.WriteLine($"la fecha es: {hoyb}");
                    Console.WriteLine($"Tipo de licuado escogido: Fresa con {tipoLeche} y {TipoAzucar}");
                    Console.WriteLine($"Cantidad total de azúcar: {cantidadAzucar} cucharaditas");
                    Console.WriteLine($"Precio total del licuado: Q.{preciototal}");
                    Console.WriteLine(" ");
                    Console.WriteLine(" Para aceptar: si");
                    Console.WriteLine(" Para denegar: no");
                    string on = Console.ReadLine();
                    {
                    if (on == "si")
                    {
                        Console.WriteLine(" ");
                        Console.WriteLine("Efectuando pago...");
                        Console.WriteLine("Por favor ingrese su número de tarjeta");
                        string tarjeta= Console.ReadLine();
                        Console.WriteLine("Ingrese el CVV (los tres números de atrás)");
                        string CVV= Console.ReadLine();
                        Console.WriteLine(" ");
                        Console.WriteLine("El pago ha sido completado con éxito");
                        Console.WriteLine("Entregando pedido...");
                        Console.WriteLine(" ");
                        aceptar = true;
                    Console.WriteLine("Orden entregada :D, ¡disfrute de su licuado!");
                    Console.WriteLine("Si tiene alguna queja o inquietud por favor comunicarse con servicio al cliente");
                    salir=true;
                    }
                    else
                    {
                        aceptar = false;
                    Console.WriteLine("Regresando al menú del licuado");
                    }
                    }
                    break;

                    case "6":
                    Console.WriteLine("<><><><>Máquina generadora de licuados<><><><>");
                    Console.WriteLine(" ");
                    Console.WriteLine("Proyecto pensamiento computacional");
                    Console.WriteLine("Creada por: Andrea Sofía Miranda Abrego - 1065824");
                    Console.WriteLine("Licuados sabor fresa, proximamente más sabores");
                    Console.Write(" ¿Continuar? "); //apartado hecho solo para que la sección de información sea visible y no se vaya para atrás
                    Console.ReadLine();
                    break;

                    case "7":
                    salir = true;
                    Console.WriteLine("Muchas gracias por su preferencia, vuelva pronto :D");
                    break;

                default:
                    Console.WriteLine("La opción que seleccionó no está disponible :(");
                    break;
            }
        }
        
        
    }
}