using System;

class Program
{
    static void Main() {
    Console.WriteLine( "MENU");
    Console.WriteLine("1. sumatoria");
    Console.WriteLine("2. tablas de multiplicar");
    Console.WriteLine("3. numero perfecto");
    Console.WriteLine("ingrese opcion");
    try{
    int opcion = int.Parse(Console.ReadLine());
    
    switch (opcion){
        case 1: Console.WriteLine("sumatoria");
        int n=0;
        int suma=0;
        int cont=1;
        Console.WriteLine("ingrese valor de N");
        n=int.Parse(Console.ReadLine());
        do
        {
            suma= suma + cont;
            
        }while(cont<=n);
        for (int i=1; i<=n;i++){
            if (i==n) {
                Console.Write(i);
            } else {  
            Console.Write(i+"+");
        }
        }
        Console.WriteLine("="+suma);
        break;
        case 2: Console.WriteLine("tablas de multiplicar");
        for(int j=1; j<=; j++){
            for(int j=1; j<=; j++){
            Console.Write(i*j+" ");
        }
        Console.WriteLine();
    }
        break;
        case 3: Console.WriteLine("numero perfecto");
        break;
        default: Console.WriteLine("opcion no valida");
        break;
    }
} catch (Exception ex){
Console.WriteLine("ERROR: debio ingresar un numero"+ex.GetType());
throw;
}
}
}
