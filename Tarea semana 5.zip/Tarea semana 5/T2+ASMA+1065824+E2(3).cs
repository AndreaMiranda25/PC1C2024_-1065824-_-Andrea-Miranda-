using System;

namespace  AA{

	class Program {

		static void Main(string[]args) 
		{
		    Console.WriteLine("Andrea Miranda - 1065824");

			int cantidad;
			double cantt;
			int b1=0, b5=0, b10=0, b20=0, b50=0, b100=0;
			double b001=0, b025=0;
	
			string can;															

			System.Console.WriteLine("Ingresar la cantidad de dinero total.");				
			can = Console.ReadLine();												
			cantidad = int.Parse(can);	
			cantt = double.Parse(can);

			if (cantt >= 0.01){														

				b001 = cantt / 0.01;													
				cantt = cantt - (b001 * 0.01);											
				System.Console.WriteLine("Tienes {0} monedas de un centavo", b001);		
			}
			if (cantt >= 0.25){														

				b025 = cantt / 0.25;													
				cantt = cantt - (b025 * 0.25);											
				System.Console.WriteLine("Tienes {0} monedas de 25 centavos", b025);
			}
				if (cantidad >= 1){														

				b1 = cantidad / 1;													
				cantidad = cantidad - (b1 * 1);											
				System.Console.WriteLine("Tienes {0} monedas de un quetzal", b1);
			}
			if (cantidad >= 5){														

				b5 = cantidad / 5;													
				cantidad = cantidad - (b5 * 5);											
				System.Console.WriteLine("Tienes {0} billetes de 5", b5);
			}
			if (cantidad >= 10){														

				b10 = cantidad / 10;													
				cantidad = cantidad - (b10 * 10);											
				System.Console.WriteLine("Tienes {0} billetes de 10", b10);
			}
			if (cantidad >= 20){														

				b20 = cantidad / 20;													
				cantidad = cantidad - (b20 * 20);											
				System.Console.WriteLine("Tienes {0} billetes de 20", b20);
			}
			if (cantidad >= 50){														

				b50 = cantidad / 50;													
				cantidad = cantidad - (b50 * 50);											
				System.Console.WriteLine("Tienes {0} billetes de 50", b50);
			}
			if (cantidad >= 100){														

				b100 = cantidad / 100;													
				cantidad = cantidad - (b100 * 100);											
				System.Console.WriteLine("Tienes {0} billetes de 100", b100);
			}

			

		}
	}
}