using System;

class Program
{
    static void Main() 
    {
        Console.WriteLine("Calcular movimiento rectilíneo uniforme");
            Console.WriteLine("ingresar la velocidadi");
        int num1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese la aceleracion");
            int num2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el tiempo");
            int num3 = int.Parse(Console.ReadLine());
            
        int multiplicacion =num2*num3;
        int velocidadf= num1 + multiplicacion;

        Console.Write("La velocidad final es: " + velocidadf);
        
        Console.ReadKey();
    }
}