using System;

class Program
{
    static void Main(string []args)
        {
            Console.WriteLine("Mi segundo programa");
             Console.WriteLine("Ingrese su nombre");
            string nombre = Console.ReadLine(); 
             Console.WriteLine("Ingrese su edad");
            string edad = Console.ReadLine(); 
             Console.WriteLine("Ingrese su carrera");
            string carrera = Console.ReadLine(); 
             Console.WriteLine("Ingrese su carné");
            string carné = Console.ReadLine();
            
            Console.WriteLine("Soy:" + nombre);
            Console.WriteLine("Soy:" + edad);
            Console.WriteLine("Soy:" + carrera);
            Console.WriteLine("Soy:" + carné);
            Console.ReadKey();
        }
}