﻿
public class multiplicacion {

public static int[,] multiplicar(int[,] matriz, int escalar){

    int cantFilas = matriz.GetLength(0);
    int cantColumnas = matriz.GetLength(1);
    //definir la nueva matriz
    int[,] nueva = new int[cantFilas, cantColumnas];

    for (int f=0; f<cantFilas; f++){
        for (int c=0; c<cantColumnas; c++){
            nueva[f, c] = matriz[f, c] * escalar;
        }
    }
    return nueva;
} //multiplicar

public static void mostrarMatriz(int[,] matriz){
    for (int f = 0; f<matriz.GetLength(0); f++){
        for(int c=0; c<matriz.GetLength(1); c++){
            Console.Write(matriz[f,c]+" , ");
        }
        Console.WriteLine();
    }
}

public static void Main(string [] args){
    string opcion = "";
    do{
Console.WriteLine("<________MENÚ________>");
Console.WriteLine("1. multiplicar matrices");
Console.WriteLine("4. salir");
opcion = Console.ReadLine();
switch(opcion){
    case "1": Console.WriteLine(" Ingrese la cantidad de filas");
    int filas = int.Parse(Console.ReadLine());
    Console.WriteLine("Ingrese columnas");
    int cols = int.Parse(Console.ReadLine());
    // CREA LA MATRIZ N DE FILASXCOLS
    int[,] n = new int[filas, cols];
    //llena la matriz
    for (int f=0; f<filas; f++){
        for (int c=0; c<cols; c++){
            Console.WriteLine("Ingrese valor para fila "+f+" col" +c);
            n[f, c]= int.Parse(Console.ReadLine());
        }
    }
    Console.WriteLine("Ingrese valor a escalar");
    int e = int.Parse(Console.ReadLine());
    int [,] nuevaMatriz = multiplicar(n, e);
    mostrarMatriz(nuevaMatriz);
    break;
}
}
while (opcion != "4");
}
}