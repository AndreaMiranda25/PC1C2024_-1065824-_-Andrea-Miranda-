using System;

class Program
{
    static void Main(string []args)
        {
            Console.WriteLine("Hola Mundo soy Andrea Miranda");
    
            Console.WriteLine("Ingrese su nombre");
            string Nombre = Console.ReadLine(); 
            Console.WriteLine("Hola Mundo");
            Console.WriteLine("Soy + Nombre");
            
            /*COMENTARIOS*/
            
            Console.Write("Hola Mundo");
            Console.Write("Soy + Nombre");
            Console.ReadKey();
        }
}