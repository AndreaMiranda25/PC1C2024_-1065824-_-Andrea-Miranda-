using System;

class Program
{
    static void Main() {
        Console.WriteLine("Ejercicio 1: Operaciones aritmeticas");
        //Entrada ingresar dos numeros
        //mensaje para ingreso del primero
        Console.WriteLine("ingresar primer numero");
        //lee el primero y lo convierte
        int num1 = int.Parse(Console.ReadLine());
        //mensaje para ingreso del segundo
        Console.WriteLine("ingresar segundo numero");
        //lee el segundo y lo convierte
        int num2 = int.Parse(Console.ReadLine());
        //procesos aritmeticos
        int suma = num1+num2;
        int resta = num1-num2;
        double division = num1/num2;
        int multiplicacion =num1*num2;
        int diventera = num1/num2;
        int modulo = num1 % num2;
        Console.WriteLine(num1+"+"+num2+"="+suma);
        Console.WriteLine(num1+"-"+num2+"="+resta);
        Console.WriteLine(num1+"*"+num2+"="+multiplicacion);
        Console.WriteLine(num1+"/"+num2+"="+division);
        Console.WriteLine(num1+"DIV"+num2+"="+diventera);
        Console.WriteLine(num1+"MOD"+num2+"="+modulo);
    }
}