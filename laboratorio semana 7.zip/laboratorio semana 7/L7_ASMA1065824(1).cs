using System;

class Program
{
    static void Main(string [] args) {
        int opcion = 0;
        do
{
     Console.WriteLine("----MENU----");
    Console.WriteLine("1, serie del zodiaco");
    Console.WriteLine("2, serie numerica");
    Console.WriteLine("Ingrese opcion:");
    int opcion = int.Parse(Console.ReadLine());
    
    switch (opcion){
        case 1: Console.WriteLine("serie del zodiaco");
        Console.WriteLine("Ingrese año");
        int año = int.Parse(Console.ReadLine());
        Console.WriteLine("Ingrese mes");
        int mes = int.Parse(Console.ReadLine());
        Console.WriteLine("Ingrese dia");
        int dia = int.Parse(Console.ReadLine());
        if (mes >=1 && mes <=12 ){
        if ((dia >=20 && mes ==1)  || (dia<=18 && mes == 2))}{
            Console.WriteLine("SIGNO ACUARIO");
               }else if ((dia >=19 && mes ==2)  || (dia<=20 && mes == 3)){
            Console.WriteLine("SIGNO PISCIS");
        }
        }else{
            Console.WriteLine("ERROR: Mes debe estar entre 1 y 12");
        }
        break;
        case 2: Console.WriteLine("serie numerica");
        Console.WriteLine("ingrese un numero");
        int num = int.Parse(Console.ReadLine());
        double x=1;
        double total = 0;
        while (x<=num){
        total= total+(1/x); 
        x=x+1; 
        }
        break;
        case 3: Console.WriteLine("opcion no valida");
        break;
    } while(opcion = 3);
 }
}

