using System;

class Program
{
    static void Main(string[] args)
    {
        string numero = "x";
        do
        {
        Console.WriteLine("Ingrese su día de nacimiento");
        int dia = int.Parse(Console.ReadLine());

        Console.WriteLine("Ingrese su mes de nacimiento");
        int mes = int.Parse(Console.ReadLine());

        Console.WriteLine("Ingrese su año de nacimiento");
        int año = int.Parse(Console.ReadLine());

        if ((mes == 3 && dia >= 21) || (mes == 4 && dia <= 19))
        {
            Console.WriteLine("SU SIGNO ES ARIES");
        }
        else if ((mes == 4 && dia >= 20) || (mes == 5 && dia <= 20))
        {
            Console.WriteLine("SU SIGNO ES TAURO");
        }
        else if ((mes == 5 && dia >= 21) || (mes == 6 && dia <= 20))
        {
            Console.WriteLine("SU SIGNO ES GÉMINIS");
        }
        else if ((mes == 6 && dia >= 21) || (mes == 7 && dia <= 22))
        {
            Console.WriteLine("SU SIGNO ES CANCER");
        }
        else if ((mes == 7 && dia >= 23) || (mes == 8 && dia <= 22))
        {
            Console.WriteLine("SU SIGNO ES LEO");
        }
        else if ((mes == 8 && dia >= 23) || (mes == 9 && dia <= 22))
        {
            Console.WriteLine("SU SIGNO ES VIRGO");
        }
        else if ((mes == 9 && dia >= 23) || (mes == 10 && dia <= 22))
        {
            Console.WriteLine("SU SIGNO ES LIBRA");
        }
        else if ((mes == 10 && dia >= 23) || (mes == 11 && dia <= 21))
        {
            Console.WriteLine("SU SIGNO ES ESCORPIO");
        }
        else if ((mes == 11 && dia >= 22) || (mes == 12 && dia <= 21))
        {
            Console.WriteLine("SU SIGNO ES SAGITARIO");
        }
        else if ((mes == 12 && dia >= 22) || (mes == 1 && dia <= 19))
        {
            Console.WriteLine("SU SIGNO ES CAPRICORNIO");
        }
        else if ((mes == 1 && dia >= 20) || (mes == 2 && dia <= 18))
        {
            Console.WriteLine("SU SIGNO ES ACUARIO");
        }
        else if ((mes == 2 && dia >= 19) || (mes == 3 && dia <= 20))
        {
            Console.WriteLine("SU SIGNO ES PISCIS");
        }
        else
        {
            Console.WriteLine("Ingresó un dato no válido, no se pudo determinar el signo correspondiente");
        }
        Console.WriteLine("¿Le gustaría ingresar otra fecha de nacimiento? puede seguir o colocar no para terminar");
        } while (numero == "x");
}
}