﻿using System;
using Laboratorio_poo_ASMA_1065824;

//principal
static void Main(String[] args) {
    int opcion = 0;
Sala misala = new Sala();
do{
    Console.WriteLine("Menu de la sala de cine");
    Console.WriteLine("1. vaciar sala");
    Console.Write("2. reservar asiento");
    Console.WriteLine("3. visualizar sala");
     Console.WriteLine("7. salir");
      Console.WriteLine("Ingrese opcion: ");
      opcion = int.Parse(Console.ReadLine());


      switch(opcion){
        case 1: misala.vaciarSala();
        break;
        case 2:  
        Console.WriteLine("Ingrese fila a reserar");
        int fila = int.Parse(Console.ReadLine());
        Console.WriteLine("Ingrese columna a reserar");
        int col = int.Parse(Console.ReadLine());
        Boolean sePudoReservar = misala.reservarAsiento(fila, col);
        if (sePudoReservar == true){
            Console.WriteLine("Asiento ["+fila+", "+col+"] reservado ");
        }

        break;
        case 3: misala.visualizarSala();
        break;
      }
} while(opcion !=7);
}
