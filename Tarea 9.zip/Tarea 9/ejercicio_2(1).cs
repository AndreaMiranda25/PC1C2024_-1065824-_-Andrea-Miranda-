namespace ejercicio_2;

public class Videojuego
{
public int X;
public int Y;
public Videojuego(x, y)
    {
    X = 0;
    Y = 0;
    }

public void MoverHaciaArriba(int cantidad)
    {
    Y += cantidad;
    }

public void MoverHaciaAbajo(int cantidad)
    {
    Y -= cantidad;
    }

public void MoverHaciaLaDerecha(int cantidad)
    {
    X += cantidad;
    }

public void MoverHaciaLaIzquierda(int cantidad)
    {
    X -= cantidad;
    }

public void MostrarCoordenadasFinales()
    {
    console.WriteLine("Las coordenadas de su personaje son:  " + X + "," + Y);
    }
}

namespace ejercicio_2;
{
    static void Main(string [] args)
    {
        string opcion;
        int cantidad;

        do
        {
        Console.WriteLine("Seleccione una opción:");
        Console.WriteLine("1. Subir");
        Console.WriteLine("2. Bajar");
        Console.WriteLine("3. Izquierda");
        Console.WriteLine("4. Derecha");
        Console.WriteLine("5. Salir");

        opcion = Console.ReadLine().ToLower();

            switch (opcion)
            {
                case "1":
                    Console.WriteLine("Ingrese cuantas veces quiere moverse hacia arriba: ");
                    cantidad = int.Parse(Console.ReadLine());
                    juego.MoverHaciaArriba(cantidad);
                    break;
                case "2":
                    Console.WriteLine("Ingrese cuantas veces quiere moverse hacia abajo: ");
                    cantidad = int.Parse(Console.ReadLine());
                    juego.MoverHaciaAbajo(cantidad);
                    break;
                case "3":
                    Console.WriteLine("Ingrese cuantas veces quiere moverse a la derecha: ");
                    cantidad = int.Parse(Console.ReadLine());
                    juego.MoverHaciaLaIzquierda(cantidad);
                    break;
                case "4":
                    Console.WriteLine("Ingrese cuantas veces quiere moverse a la derecha: ");
                    cantidad = int.Parse(Console.ReadLine());
                    juego.MoverHaciaLaDerecha(cantidad);
                    break;
                case "5":
                    Console.WriteLine("Ha salido del juego :D");
                    break;
                default:
                    Console.WriteLine("Has seleccionado una opción no válida");
                    break;
            }

        } while (opcion = "5");

        juego.MostrarCoordenadasFinales();
    }
}