namespace L9_ASMA_1065824;

Public class Operaciones {
    //Devuelve el area de u triangulo usando su base y altura para el cálculo 
    Public double ObtenerAreaTriangulo( double base, double altura){
        double area = (base * altura)/2;
        return area;
    }
    //devuelve el area del cuadrado usando el lado para el calculo
    public double obtenerareacuadrado(double lado){
        double area = lado * lado;
        return area;
    }
}
