﻿namespace SegundaFase_proyecto2_ASMA_1065824;
public class Piezas
{
    public string Color {get; set;}
    public string TipoPieza {get; set;}
    public string PosPiezas {get; set;}
   

    public Piezas(string tipoPieza, string color, string posPiezas)
    {
        //definir
        Color = color;
        TipoPieza = tipoPieza;
        PosPiezas = posPiezas; 

    }
}


    