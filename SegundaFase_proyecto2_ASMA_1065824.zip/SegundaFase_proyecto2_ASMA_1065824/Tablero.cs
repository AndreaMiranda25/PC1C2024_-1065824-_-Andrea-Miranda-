﻿using System;
namespace SegundaFase_proyecto2_ASMA_1065824;
using SegundaFase_proyecto2_ASMA_1065824;

//Matriz del tablero
   class Tablero
{
    private Piezas[,] tablero;

    public Tablero()
{
    tablero = new Piezas[8, 8];
    }
    
 public void MostrarTablero()
    {
        for (int fila = 0; fila < 8; fila++)
        {
            for (int columna = 0; columna < 8; columna++)
            {
                Piezas pieza = tablero[fila, columna];
                Console.Write(pieza != null ? pieza.TipoPieza[0] + (pieza.Color == "B" ? "B" : "N") : " O ");
            }
            Console.WriteLine();
        }
    }


//Colocar la pieza en el tablero
    public int ColocarColumna(char letra) //relaciona la letra al número de columnas
    {
    return letra - 'a';
    }

    public int ColocarFila(char numero) //relaciona el número al número de filas
    {
        return numero - '1';
}

    public bool PosicionPieza(int fila, int columna) //constructor que define el orden (fila, columna) y el rango numerico para las filas y columnas
    {
        return fila >= 0 && fila < 8 && columna >= 0 && columna < 8;
    }

public Piezas PiezaEnPosicion(int fila, int columna) //verifica si la pieza se encuentra dentro del rango numerico ya establecido y se le da una posicion en el tablero ajska
{
    return tablero[fila, columna];
    }

public void AgregarPiezas(Piezas pieza) //Aquí ya se agregarán las piezas
    {
        int columna = ColocarColumna(pieza.PosPiezas[0]);
        int fila = ColocarFila(pieza.PosPiezas[1]);

        if (PosicionPieza(fila, columna) && tablero[fila, columna] == null) //condición que indica de que si la posición está vacía
        {
            tablero[fila, columna] = pieza;
        }
        else
        {
            Console.WriteLine("La posición escogida ya ha sido tomada, elegir otra");
        }
 }

private string VerPosicion(int fila, int columna) //se agrupan los numeros y letras de fila y columna
    {
        return ((char)(columna + 'a')).ToString() + (fila + 1).ToString();
    }


//Colocar y evaluar a la dama o reina en el tablero
public void MoverDama(string posicionInicial, string posicionFinal) //define el movimiento de la pieza dentro de la matriz
    {
        int iniciocolumna = ColocarColumna(posicionInicial[0]);
        int iniciofila = ColocarFila(posicionInicial[1]);
        int finalcolumna = ColocarColumna(posicionFinal[0]);
        int finalfila = ColocarFila(posicionFinal[1]);

        if (PosicionPieza(iniciofila, iniciocolumna) && PosicionPieza(finalfila, finalcolumna))
        {
        if (tablero[finalfila, finalcolumna] != null)
        {
            Console.WriteLine("Casilla ocupada, pieza comida.");
            }

        tablero[finalfila, finalcolumna] = tablero[iniciofila, iniciocolumna];
            tablero[iniciofila, iniciocolumna] = null;
            Console.WriteLine("Su pieza se ha movido a: " + VerPosicion(finalfila, finalcolumna));
        }
        else
        {
            Console.WriteLine("Revisar movimiento, no se ha podido mover");
        }
    }

    public List<string> ObtenerMovimientosDama(string posiciondama) //se crea una lista para obtener los posibles movimientos de la dama 
{
    List<string> movimientos = new List<string>();
    int iniciocolumna = ColocarColumna(posiciondama[0]);
    int iniciofila = ColocarFila(posiciondama[1]);

    int[] direcciones = { -1, 0, 1 };
        for (int i = 0; i < direcciones.Length; i++)
        {
            for (int j = 0; j < direcciones.Length; j++)
            {
                int df = direcciones[i];
                int dc = direcciones[j];

                if (df == 0 && dc == 0)
                continue;

            int filaActual = iniciofila + df;
            int columnaActual = iniciocolumna + dc;

            if (PosicionPieza(filaActual, columnaActual))
                {
                    string posicion = VerPosicion(filaActual, columnaActual);
                    if (tablero[filaActual, columnaActual] != null)
                    {
                        posicion += " (ocupada)";
                    }
                    movimientos.Add(posicion);
            }
}
    }

        return movimientos;
    }

public void EvaluarDama(string posicionInicial, string colordama) //se evalúa la posición inicial y su color, se imprime y luego se evalua la posicion final disponible en base a sus movimientos
{
    int damaColumna = ColocarColumna(posicionInicial[0]);
    int damaFila = ColocarFila(posicionInicial[1]);

    if (PosicionPieza(damaFila, damaColumna))
    {
    Piezas dama = new Piezas("Dama", colordama == "B" ? "B" : "N", posicionInicial);
        tablero[damaFila, damaColumna] = dama;

    Console.WriteLine("Vista del tablero: ");
    MostrarTablero();

    List<string> movimientos = ObtenerMovimientosDama(posicionInicial);
    Console.WriteLine("Posibles movimientos de la Dama:");
        for (int i = 0; i < movimientos.Count; i++)
        {
            Console.WriteLine($"{i + 1}. {movimientos[i]}");
            }

        Console.WriteLine("Seleccione el número del movimiento deseado:");
        int opcion = int.Parse(Console.ReadLine()) - 1;

        if (opcion >= 0 && opcion < movimientos.Count)
            {
                string movimientoSeleccionado = movimientos[opcion].Split(' ')[0];
                MoverDama(posicionInicial, movimientoSeleccionado);

                Console.WriteLine("Vista del tablero después del movimiento de la dama:");
                MostrarTablero();
        }
            else
            {
                Console.WriteLine("La opción que seleccionó no está disponible");
            }
    }
    else
    {
        Console.WriteLine("La posición que usted ingresó no existe");
}
}
}

