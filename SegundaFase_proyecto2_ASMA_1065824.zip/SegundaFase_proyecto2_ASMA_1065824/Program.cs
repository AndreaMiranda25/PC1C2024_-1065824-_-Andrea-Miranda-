﻿using System;
using SegundaFase_proyecto2_ASMA_1065824;


class Program
{

    static void Main(string[] args)
    {
        Tablero tablero = new Tablero(); //declarada afuera para que sirva fuera del ciclo for
        bool salir = false;
        while(!salir) 
        {
        Console.WriteLine(" MENU ");
        Console.WriteLine("1. Elegir pieza ");
        Console.WriteLine("2. Ver tablero ");
        Console.WriteLine("3. Evaluar dama ");
        Console.WriteLine("4. Salir ");
        string opcion = Console.ReadLine();
         
        switch(opcion){
            case "1":
            Console.WriteLine("Seleccione la cantidad de piezas a colocar");
            int cantidad = int.Parse(Console.ReadLine());
            
           
            for(int i = 0; i < cantidad; i++) //bucle de piezas dependiendo cuántas escoga la persona al agregar 
                {
                    Console.WriteLine(" ");
                
                    Console.WriteLine("¿Qué pieza desea escoger? (seleccionar la letra) ");
                    Console.WriteLine("Opciones: ");
                    Console.WriteLine("Rey: R");
                    Console.WriteLine("Torre: T");
                     Console.WriteLine("Peon: P");
                      Console.WriteLine("Alfil: A");
                    Console.WriteLine("Caballo: C");
                    String tipoPieza = Console.ReadLine();
                    Console.WriteLine(" ");
                    Console.WriteLine("¿Qué color desea escoger? (Seleccionar letra)");
                    Console.WriteLine("Opciones: ");
                    Console.WriteLine("Blanco: B");
                    Console.WriteLine("Negro: N");
                    string color = Console.ReadLine();
                    Console.WriteLine(" ");
                    Console.WriteLine("¿En qué posición desea colocar su pieza?");
                    Console.WriteLine("Escribir la fila y columna junta. Ejemplo: a1");
                    Console.WriteLine("filas: 1, 2, 3, 4, 5, 6, 7, 8");
                    Console.WriteLine("Columnas: a, b, c, d, e, f, g, h");
                    String posPiezas = Console.ReadLine();

                    Piezas pieza = new Piezas(tipoPieza, color, posPiezas);
                    tablero.AgregarPiezas(pieza);
                }
                Console.WriteLine("Vista actual del tablero:");
                    tablero.MostrarTablero();

                    Console.WriteLine("¿Desea salir al menú?");
                    string menu = Console.ReadLine();
                    if (menu == "si")
                    {
                        Console.WriteLine("");
                    }
            break;
            case "2":
            Console.WriteLine("¿Desea ver el tablero?");
             string confir = Console.ReadLine();
            if (confir == "si")
            {
                Console.WriteLine("Representación del tablero: ");
                tablero.MostrarTablero();
            }
            else
            {
                
            }
            break;
            case "3":
           Console.WriteLine("¿Qué color desea para su dama?");
           Console.WriteLine("Blanco: B");
           Console.WriteLine("Negro: N");
                    string colordama = Console.ReadLine();
                    Console.WriteLine("Ingrese la posición inicial de la dama (ejemplo: a1): ");
                    string posicionInicial = Console.ReadLine();
                    tablero.EvaluarDama(posicionInicial, colordama);
                    break;
           

            case "4":
            Console.WriteLine("¿Desea salir?");
            string si = Console.ReadLine();
            if (si == "si")
            {
                salir = true;
                Console.WriteLine("");
            }
            else
            {
                Console.WriteLine("Regresando al menú...");
            }
            break;
    }
    }
    }
    }

