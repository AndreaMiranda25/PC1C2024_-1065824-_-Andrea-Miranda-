using System;

class Program
{
    static void Main(string [] args)
    {
        Console.WriteLine("En el siguiente ejercicio se le va a solicitar un número para convertirlo a hexadecimal y binario");
        Console.WriteLine("Ingrese cualquier numero");
        int num = int.Parse(Console.ReadLine());

        string hexa = Convert.ToString(num, 16);
        Console.WriteLine($"El número que puso en tipo hexadecimal es: {hexa}");
        string bin = Convert.ToString(num, 2);
        Console.WriteLine($"El número que puso en tipo binario es: {bin}");
       
    }
}