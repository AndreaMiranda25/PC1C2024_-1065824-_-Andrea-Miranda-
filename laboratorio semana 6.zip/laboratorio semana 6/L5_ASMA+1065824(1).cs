using System;

class Program
{
    static void Main() {
        Console.WriteLine("Ejercicio 1");
        int dato=0;
        Console.WriteLine("Ingrese un numero entero");
        dato= int.Parse(Console.ReadLine());
        if (dato>0){
            Console.WriteLine("es positivo") ;
    }
    else if (dato==0){
        Console.WriteLine("es cero");
    }
    else {
        Console.WriteLine("es negativo");
    }
    Console.ReadKey();
  }
}