﻿namespace Lab10_ASMA_1065824
{
Public class circulo
{
private double radio;
Public circulo(double radio);

}

private double obtenerperimetro
{
    return 2 * radio * 3.141592653;
}

private double obtenerarea
{
    return radio^2 * 3.141592653;
}

private double obtenervolumen
{
    return (4*3.141592653*radio^3/3);
}


}


