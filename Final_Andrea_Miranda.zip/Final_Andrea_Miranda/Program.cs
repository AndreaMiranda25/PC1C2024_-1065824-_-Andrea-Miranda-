﻿using System;
using Final_Andrea_Miranda;

class Program
{
    static void Main(string[] args)
    {

        Agregarcliente agregarclientes = new Agregarcliente(); //Llamar agregarclientes
        
        bool salir = false; //bucle del menú
        while(!salir) 
        {
        Console.WriteLine(" ");
        Console.WriteLine("--------MENÚ GIMNASIO--------");
        Console.WriteLine("1. Ingreso de datos (por entidad) ");
        Console.WriteLine("2. Mostrar datos ");
        Console.WriteLine("3. Salir del programa ");
        Console.WriteLine(" ");
        string opcion = Console.ReadLine();
        //Ejecución del menú de arriba 
        switch(opcion){
            case "1":
            agregarclientes.DatosCliente();
            break;

            case "2":
            //switch anidado creado para completar el sub menú
            Console.WriteLine(" ");
            Console.WriteLine("1. Listado de clientes con membresía activa ");
            Console.WriteLine("2. Consultar catálogo clases (lecciones)");
            Console.WriteLine("3. Listado Instalaciones disponibles (sedes) ");
            Console.WriteLine("Seleccione la opcion de preferencia");
            Console.WriteLine(" ");
            string opcion2 = Console.ReadLine();
            switch(opcion2){
                case "1":
                Console.WriteLine("Información del cliente");
                agregarclientes.MostrarDatosClientes(); //llamar al método creado en la clase Agregarclientes
                break;

                case"2": //lista de las lecciones disponibles
                Console.WriteLine("--------Catálogo de lecciones disponibles--------");
                Console.WriteLine("1. Aerobic");
                Console.WriteLine("2. Yoga");
                Console.WriteLine("3. CrossFit");
                Console.WriteLine("4. Pilates");
                Console.WriteLine("5. Boxeo");
                Console.WriteLine("6. Zumba");
                Console.WriteLine(" ");
                break;

                case"3": //lista de las sedes disponibles
                Console.WriteLine("--------Sedes disponibles--------");
                Console.WriteLine("1. 1ra Avenida A 10-50, Cdad de Guatemala 01001 || +502 4595 1070");
                Console.WriteLine("2. Carr. a el Sausalito, Cdad de Guatemala || +502 8945 2212");
                Console.WriteLine("3. HHF4+79R, C. central Piedra Parada, Cdad de Guatemala || +502 6769 8723");
                Console.WriteLine(" ");
                break;
            }
            break;
            case "3": //se rompe el bucle con true
            Console.WriteLine("¿Desea salir del programa?");
            Console.WriteLine("Sí = s");
            Console.WriteLine("No = n");
            string salpro = Console.ReadLine();

            if(salpro == "s")
            {
                salir = true;
            }

            else if(salpro == "n")
            {
                salir = false;
            }

            else
            {
                Console.WriteLine("La opcion escogida no es válida");
            }
            break;
            default:
            Console.WriteLine("La opción escogida no está en el menú, ingresarla nuvamente");
            salir= false;
            break;
            }
         }
     }
}