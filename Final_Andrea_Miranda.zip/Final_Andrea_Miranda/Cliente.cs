﻿
namespace Final_Andrea_Miranda;

class Cliente
    {
        //Datos del cliente
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public string Sexo { get; set; }
        public int Dpi { get; set; }
        public bool MembresiaActiva { get; set; }
        public string Nitt { get; set; }
        public List<string> LeccionesAgregadas { get; set; }
        public string Documentoidentificacion { get; set; }
        public string Sede { get; set; } 
        public Cliente()
        {

        }
        public Cliente(string nombre, string apellido, string sexo, DateTime fechaNacimiento, string documentoidentificacion, string nitt, bool membresiaActiva)
        {
            Nombre = nombre;
            Apellido = apellido;
            Sexo = sexo;
            FechaNacimiento = fechaNacimiento;
            Documentoidentificacion = documentoidentificacion;
            Nitt = nitt;
            MembresiaActiva = membresiaActiva;
            LeccionesAgregadas = new List<string>();
        
        }      
    }
