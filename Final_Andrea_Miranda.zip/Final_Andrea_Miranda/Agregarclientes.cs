﻿namespace Final_Andrea_Miranda;
using Final_Andrea_Miranda;
using System;
public class Agregarcliente
{
    private List<Cliente> clientes = new List<Cliente>();
    
    //Declaración de variables afuera para usarlas después
    string documentoidentificacion = " ";
    string nitt = " ";
    bool GYMPLUS = true;
     public void DatosCliente( ) //Mostrará los datos a pedir del cliente
        {
            
            Console.WriteLine("Ingrese su nombre: ");
            string nombre = Console.ReadLine();

            Console.WriteLine("Ingrese su apellido: ");
            string apellido = Console.ReadLine();

            Console.WriteLine("Ingrese su sexo: ");
            Console.WriteLine("Femenino: f");
            Console.WriteLine("Masculino: m");
            string sexo = Console.ReadLine();


            bool salir2 = false;
            bool salir3 = false;
            while(!salir2) 
            {
            Console.WriteLine("Ingrese su DPI (13 numeros)");
            documentoidentificacion = (Console.ReadLine());
            if( documentoidentificacion.Length == 13)
                {
                  Console.WriteLine("Se ha registrado su DPI");  
                  salir2 = true;
                }
            else
            {
                Console.WriteLine("Su número de DPI no es válido, reintentar");
                salir2 = false;
            }
            }	

            while(!salir3)
            {
            Console.WriteLine("Ingrese su NIT (8 numeros)");
            nitt = (Console.ReadLine());
            if( nitt.Length == 8)
                {
                    Console.WriteLine("Se ha registrado su NIT"); 
                    salir3 = true;
                }
            else
            {
                Console.WriteLine("Su número de NIT no es válido, reintentar");
                salir3 = false;
            }
            }

            Console.WriteLine("Ingrese su fecha de nacimiento (dd/mm/yyyy): ");
            DateTime fechaNacimiento = DateTime.Parse(Console.ReadLine());


            //Suscripción a la membresía del gimnasio
            Console.WriteLine("¿Desea suscribirse a la membresía GYMPLUS del gimnasio?");
            Console.WriteLine("Sí = s");
            Console.WriteLine("No = n");
            string confirmacion = Console.ReadLine();
            if(confirmacion == "s")
            {
                Console.WriteLine("Ingrese su número de tarjeta");
                int numtar = int.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese la fecha de experación (dd/mm/yyyy) ");
                DateTime fechaex = DateTime.Parse(Console.ReadLine());
                Console.WriteLine("Ingrese el código de seguridad (3 números)");
                int numseg = int.Parse(Console.ReadLine());
                Console.WriteLine("Efectuando pago... ");
                Console.WriteLine(" ");
                Console.WriteLine("Su membresía GYMPLUS ha sido aprobada");
                GYMPLUS = true;
            }
            else
            {
                Console.WriteLine("Membresía GYMPLUS no obtenida");
                GYMPLUS = false;

            }
            Cliente nuevoCliente = new Cliente(nombre, apellido, sexo, fechaNacimiento, documentoidentificacion, nitt, GYMPLUS);


             // Asignación de lección o clase del gimnasio
            Console.WriteLine("¿Desea asignarse a una lección o clase del gimnasio?");
            Console.WriteLine("Sí = s");
            Console.WriteLine("No = n");
            string confileccion = Console.ReadLine();
        if (confileccion == "s")
        {
            Console.WriteLine("--------Catálogo de lecciones disponibles--------");
            Console.WriteLine("1. Aerobic");
            Console.WriteLine("2. Yoga");
            Console.WriteLine("3. CrossFit");
            Console.WriteLine("4. Pilates");
            Console.WriteLine("5. Boxeo");
            Console.WriteLine("6. Zumba");
            Console.WriteLine("Seleccione el número de la lección que desea agregar:");
            string opcionLeccion = Console.ReadLine();

            switch (opcionLeccion)
            {
                case "1":
                    nuevoCliente.LeccionesAgregadas.Add("Aerobic");
                    break;
                case "2":
                    nuevoCliente.LeccionesAgregadas.Add("Yoga");
                    break;
                case "3":
                    nuevoCliente.LeccionesAgregadas.Add("CrossFit");
                    break;
                case "4":
                    nuevoCliente.LeccionesAgregadas.Add("Pilates");
                    break;
                case "5":
                    nuevoCliente.LeccionesAgregadas.Add("Boxeo");
                    break;
                case "6":
                    nuevoCliente.LeccionesAgregadas.Add("Zumba");
                    break;
                default:
                    Console.WriteLine("La opción que selecciono no es valida");
                    break;
            }
        }

        //Asignación de la sede o instalaciones
        Console.WriteLine("¿Desea asignarse a una sede?");
        Console.WriteLine("Sí = s");
        Console.WriteLine("No = n");
        string confSede = Console.ReadLine();
        if (confSede == "s")
        {
            Console.WriteLine("--------Sedes disponibles--------");
            Console.WriteLine("1. 1ra Avenida A 10-50, Cdad de Guatemala 01001 || +502 4595 1070");
            Console.WriteLine("2. Carr. a el Sausalito, Cdad de Guatemala || +502 8945 2212");
            Console.WriteLine("3. HHF4+79R, C. central Piedra Parada, Cdad de Guatemala || +502 6769 8723");
            Console.WriteLine("Seleccione el número de la sede que desea agregar:");
            string opcionSede = Console.ReadLine();

            switch (opcionSede)
            {
                case "1":
                    nuevoCliente.Sede = "1ra Avenida A 10-50, Cdad de Guatemala 01001 || +502 4595 1070";
                    break;
                case "2":
                    nuevoCliente.Sede = "Carr. a el Sausalito, Cdad de Guatemala || +502 8945 2212";
                    break;
                case "3":
                    nuevoCliente.Sede = "HHF4+79R, C. central Piedra Parada, Cdad de Guatemala || +502 6769 8723";
                    break;
                default:
                    Console.WriteLine("La opción que selecciono no es valida");
                    break;
            }
        }


        clientes.Add(nuevoCliente);
    }

     public void MostrarDatosClientes()
        {
            if (clientes.Count == 0)
            {
                Console.WriteLine("No hay clientes registrados.");
                return;
            }

            Console.WriteLine("Datos de los clientes:");
            for (int i = 0; i < clientes.Count; i++)
            {
                Cliente cliente = clientes[i];
                Console.WriteLine("");
                Console.WriteLine("Nombre: " +cliente.Nombre);
                Console.WriteLine("Apellido: " +cliente.Apellido);
                Console.WriteLine("Sexo: " +cliente.Sexo);
                Console.WriteLine("Fecha de nacimiento: " +cliente.FechaNacimiento);
                Console.WriteLine("DPI: " +documentoidentificacion);
                Console.WriteLine("NIT: " +nitt);
                Console.WriteLine("Membresía: " + (cliente.MembresiaActiva ? "Activa" : "No Activa"));
                Console.WriteLine("Lecciones agregadas: " + (cliente.LeccionesAgregadas.Count > 0 ? cliente.LeccionesAgregadas[0] : "No se han asignado clases")); //uso de ternario ? para definir una condicion donde si la cantidad de lecciones que hay registradas para el usario es mayor a 0 aparecerá el nombre de la lección, sino no aparecerá que no hay ninguna.
                Console.WriteLine("Sede asignada: " + (cliente.Sede == "" ? "Ninguna" : cliente.Sede)); //uso de operador ? x2  
            }
        }
}
